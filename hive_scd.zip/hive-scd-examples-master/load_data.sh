#!/bin/sh

hdfs dfs -copyFromLocal merge_data /tmp
